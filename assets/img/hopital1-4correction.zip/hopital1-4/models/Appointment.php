<?php
require_once(dirname(__FILE__).'/../utils/database.php');

class Appointment{

   

}